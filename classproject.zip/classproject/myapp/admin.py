from django.contrib import admin
from .models import Restaurant

admin.site.register(Restaurant)
# Register your models here.

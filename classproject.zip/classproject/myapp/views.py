from django.shortcuts import render
from .models import Dish, Restaurant
from .forms import DishForm, RestaurantForm
from django.views.generic import (
    TemplateView,
    CreateView,
    UpdateView,
)


class Sample(TemplateView):
    template_name = "myapp/home.html"

class AddRestaurant(CreateView):
    model = Restaurant
    form_class = RestaurantForm
    # success_url = "/myapp/home"
    template_name = "myapp/restaurant_form.html"

class UpdateRestaurant(UpdateView):
    model = Restaurant    
    form_class = RestaurantForm
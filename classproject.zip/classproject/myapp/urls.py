from django.urls import path
from django.views.generic import TemplateView
from . import views 

urlpatterns = [
    path('',TemplateView.as_view(template_name="myapp/index.html"),name="index"),
    path('home/',views.Sample.as_view(),name="home"),
    path('addrestaurant/',views.AddRestaurant.as_view(),
                                        name="addrestaurant"),
    path('updaterestaurant/<int:pk>/',views.UpdateRestaurant.as_view(),name="updaterestaurant")                                    
]